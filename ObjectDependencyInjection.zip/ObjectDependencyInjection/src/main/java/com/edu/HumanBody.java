package com.edu;

public class HumanBody {
	private HumanHeart humanheart;

	public HumanBody(HumanHeart humanheart) {
		super();
		this.humanheart = humanheart;
	}
	public void bodyMethod() {
		if(humanheart !=null) {
			System.out.println("Human is alive");
		}
		else {
			System.out.println("Human is not alive");
			
		}
	}

}
