package com.edu;

public class HumanHeart {
	public void humanheart() {
		System.out.println("Human is alive");
	}

}
