package com.edu;

public class SpellCheck {
	public void spell() {
		System.out.println("Your spelling is correct");
	}
}

		
	


