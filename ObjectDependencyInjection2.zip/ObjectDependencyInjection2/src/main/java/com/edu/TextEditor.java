package com.edu;

public class TextEditor {
	
	
		private SpellCheck spellCheck;

		public TextEditor(SpellCheck spellCheck) {
			super();
			this.spellCheck = spellCheck;
		}
		
		public void checkSpelling() {
			if(spellCheck!=null) {
				System.out.println("Not null");
			}
			else {
				System.out.println("null");
			}
		}
	}
